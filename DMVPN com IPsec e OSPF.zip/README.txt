 DMVPN Fase 3 com IPsec e OSPF


Concluí recentemente a simulação e implementação de uma infraestrutura corporativa WAN resiliente, escalável e segura baseada em DMVPN Fase 3, utilizando IPsec para cifragem de tráfego e OSPF como protocolo de encaminhamento dinâmico. A topologia replica um cenário empresarial real, interligando uma sede central (Hub) a quatro filiais geograficamente distribuídas (Spokes) e um escritório secundário (Sub-filial).

A arquitetura foi concebida sobre uma nuvem WAN dedicada, composta por:

Nó Central (Hub): Router CENTRAL atuando como terminador principal DMVPN e controlador NHRP.

Nós Periféricos (Spokes): Routers FILIAL-1 a FILIAL-4 com as respetivas redes LAN e VPCs de teste.

Extensão de Rede (Sub-filial): O router FILIAL-4.1 conectado em suporte à FILIAL-4, simulando a expansão de um escritório secundário encadeado.

DMVPN Fase 3 (mGRE + NHRP): Adotada para permitir conectividade direta Spoke-to-Spoke dinâmica sem saturação dos recursos do Hub. Através dos mecanismos de NHRP Redirect (no Hub) e NHRP Shortcut (nos Spokes), o Hub sinaliza o caminho mais eficiente, permitindo que a comutação de tráfego ocorra na menor latência possível após a resolução inicial de endereço.
Cifragem de Tráfego com IPsec: Toda a infraestrutura sobre a interface mGRE foi blindada utilizando IPsec com algoritmos de cifra AES e autenticação SHA-256, assegurando confidencialidade, integridade e proteção contra interceptação de dados.

Encaminhamento Dinâmico OSPF (Point-to-Multipoint): Escolha estratégica para otimizar a convergência sobre enlaces mGRE. A alteração do tipo de rede OSPF padrão para Point-to-Multipoint eliminou a necessidade de eleição de DR/BDR (Designated Router / Backup Designated Router), otimizando a estabilidade das adjacências e simplificando a tabela de encaminhamento.